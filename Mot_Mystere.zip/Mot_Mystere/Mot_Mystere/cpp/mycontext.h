#ifndef MYCONTEXT_H
#define MYCONTEXT_H

#include <QObject>
#include <QString>
#include "motmystere.h"

class MyContext : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString myProperty READ getMyproperty WRITE setMyproperty NOTIFY myPropertyChanged)
    Q_PROPERTY(int choixNbDeLetrres READ getChoixNbDeLettres WRITE setChoixNbDeLettres NOTIFY ChoixNbDeLettresChanged)

public:
    explicit MyContext(QObject *parent = nullptr);

    /* *** fonctions de liasion CPP -> QML *** */
    Q_INVOKABLE void test (QString texte);

    int getChoixNbDeLettres() const;

signals:

    void myPropertyChanged();
    void sendtoQML (QString texte);

    void ChoixNbDeLettresChanged(int choixNbDeLetrres);

private:

    QString m_myproperty;
    MotMystere m_motMystere;

    int m_choixNbDeLetrres;

public slots:
  void setMyproperty(const QString &myProperty);
  QString getMyproperty() const;

  /* *** fonctions de liaison QML -> CPP *** */
  void receivedFromQMl(QString texte);

  void setChoixNbDeLettres(int choixNbDeLetrres);
};

#endif // MYCONTEXT_H
