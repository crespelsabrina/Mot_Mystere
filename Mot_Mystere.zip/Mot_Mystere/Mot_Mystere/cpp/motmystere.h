#ifndef MOTMYSTERE_H
#define MOTMYSTERE_H

#include <iostream>
#include <string>
#include <vector>


class MotMystere
{
public:
    MotMystere();


    std::string melangerLettres(std::string mot);

    void jouerPartie();
    void nouvellePartie();


};

#endif // MOTMYSTERE_H
