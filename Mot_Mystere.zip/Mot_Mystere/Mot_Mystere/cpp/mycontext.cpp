#include "mycontext.h"

#include <QApplication>
#include <QPushButton>
#include <QDebug>
#include <iostream>
#include <string>
#include <vector>


using namespace std;


MyContext::MyContext(QObject *parent) : QObject(parent)
{
    m_myproperty = "OK";
}


/* *** Fonctions QML -> CPP et CPP -> QML *** */

void MyContext::test(QString texte)
{
    qDebug() << "test ok";
}

int MyContext::getChoixNbDeLettres() const
{
    return m_choixNbDeLetrres;
}



void MyContext::setChoixNbDeLettres(int choixNbDeLetrres)
{
    if (m_choixNbDeLetrres == choixNbDeLetrres)
        return;

    m_choixNbDeLetrres = choixNbDeLetrres;
    emit ChoixNbDeLettresChanged(m_choixNbDeLetrres);


}

void MyContext::receivedFromQMl(QString texte)
{
    qDebug() << texte;
}



/* *** Gestion de QPROPERTY *** */

void MyContext::setMyproperty(const QString &myProperty)
{
    if (myProperty != m_myproperty){

        qDebug() << "MyContext::SET Myproperty()" ;
        m_myproperty = myProperty;
        emit myPropertyChanged();
    }
}

QString MyContext::getMyproperty() const
{
    qDebug() << "MyContext::GET Myproperty()" ;
    return m_myproperty;
}




