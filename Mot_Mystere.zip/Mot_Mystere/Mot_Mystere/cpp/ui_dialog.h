#ifndef UI_DIALOG_H
#define UI_DIALOG_H



class ui_dialog
{
public:
    ui_dialog();
};

#endif // UI_DIALOG_H
