#ifndef JOUEUR_H
#define JOUEUR_H

#include <QObject>
#include <QDebug>


class Joueur : QObject
{
    Q_OBJECT
    Q_PROPERTY(QString nom READ nom WRITE setNom NOTIFY nomChanged)
    Q_PROPERTY(QString motPropose READ getMotPropose WRITE setMotPropose NOTIFY motProposeChanged)


public:

    Joueur(QObject *parent = nullptr);
    Joueur *createCopy();


    QString getMotPropose() const;
    QString nom() const;


    QString getNom() const;

signals:

    void motProposeChanged(QString motPropose);
    void nomChanged(QString nom);


public slots:

    void setMotPropose(QString motPropose);
    void setNom(QString nom);

private:

    QString m_motPropose;

    QString m_nom;

};

#endif // JOUEUR_H
