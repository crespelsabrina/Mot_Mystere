#include "joueur.h"
#include <QPushButton>

Joueur::Joueur(QObject *parent)
{
    m_nom = "";
}

Joueur *Joueur::createCopy()
{
    Joueur* newJ = new Joueur();
    newJ->setNom( nom() );
    return newJ;

}

QString Joueur::getMotPropose() const
{
    return m_motPropose;
}

QString Joueur::nom() const
{
    return m_nom;
}

void Joueur::setMotPropose(QString motPropose)
{
    if (m_motPropose == motPropose)
        return;

    m_motPropose = motPropose;
    emit motProposeChanged(m_motPropose);
}

void Joueur::setNom(QString nom)
{
    if (m_nom == nom)
        return;

    m_nom = nom;
    emit nomChanged(m_nom);
}

QString Joueur::getNom() const
{
    return m_nom;
}
