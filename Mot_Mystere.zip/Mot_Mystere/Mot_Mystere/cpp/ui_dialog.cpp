#include "ui_dialo

using namespace std;

ui_dialog::ui_dialog()
{

}
